const API_KEY = "AIzaSyBL2vInqJuGtCjhp2wO2mlyRcQ_zxmnHI0"; // Replace with your actual key
const chat = document.getElementById("chat");

async function sendMessage() {
  const input = document.getElementById("userInput");
  const userMessage = input.value;
  input.value = "";

  appendMessage("You", userMessage);

  const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + API_KEY, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: userMessage }] }]
    })
  });

  const data = await response.json();
  const botReply = data.candidates?.[0]?.content?.parts?.[0]?.text || "No reply.";
  appendMessage("Gemini", botReply);
}

function appendMessage(sender, message) {
  const msg = document.createElement("div");
  msg.innerHTML = `<strong>${sender}:</strong> ${message}`;
  chat.appendChild(msg);
}